
document.getElementById("clickMe").onclick = function () { alert('hello!'); };
